package com.measify.kappmaker.domain.exceptions

class UnAuthorizedException() : Exception("You need to be logged in to do this operation")