package com.measify.kappmaker.util

import androidx.compose.runtime.Composable

interface ScreenRoute  {

    @Composable
    fun Content()
}