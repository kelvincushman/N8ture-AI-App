package com.measify.kappmaker.domain.exceptions

class PurchaseRequiredException :
    Exception("You need to have a premium subscription to make this operation")