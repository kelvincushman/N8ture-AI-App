package com.measify.kappmaker.presentation.components

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier

@Composable
expect fun ExampleNativeTextView(text: String, modifier: Modifier = Modifier)