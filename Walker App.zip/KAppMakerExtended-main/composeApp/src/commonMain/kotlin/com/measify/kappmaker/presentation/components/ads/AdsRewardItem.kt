package com.measify.kappmaker.presentation.components.ads

data class AdsRewardItem(val amount: Int, val type: String)
