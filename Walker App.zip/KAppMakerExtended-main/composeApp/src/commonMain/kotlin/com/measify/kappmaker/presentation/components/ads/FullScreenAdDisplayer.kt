package com.measify.kappmaker.presentation.components.ads

interface FullScreenAdDisplayer {
    fun show()
}