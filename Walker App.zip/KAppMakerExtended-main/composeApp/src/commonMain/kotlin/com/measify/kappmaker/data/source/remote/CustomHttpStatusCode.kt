package com.measify.kappmaker.data.source.remote

object CustomHttpStatusCode {
    const val PURCHASE_REQUIRED = 1002
}