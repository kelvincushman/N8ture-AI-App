package com.measify.kappmaker.data.source.remote.response

import kotlinx.serialization.Serializable

@Serializable
class ExampleResponse {
}