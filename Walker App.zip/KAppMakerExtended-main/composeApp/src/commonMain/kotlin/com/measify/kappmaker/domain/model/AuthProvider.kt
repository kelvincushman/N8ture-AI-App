package com.measify.kappmaker.domain.model

enum class AuthProvider {
    GOOGLE, APPLE
}