package com.measify.kappmaker.presentation.components.ads

interface FullScreenAdLoader {
    fun load()
}