package com.measify.kappmaker.data.source.remote.request

import kotlinx.serialization.Serializable

@Serializable
class ExampleRequest {
}