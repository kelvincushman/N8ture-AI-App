package com.measify.kappmaker.designsystem.theme

import androidx.compose.runtime.Composable

@Composable
internal actual fun SystemAppearance(isDark: Boolean) {
    //No op
}