_This is a text-based mockup of the home screen._

# Home Screen

*   **[Image of the app logo]**
*   **Welcome Message:** "Welcome, [User Name]!"
*   **Identify Button:** A large, prominent button with a camera icon, labeled "Identify".
*   **Recent Identifications:** A horizontally scrollable list of the user's most recent identifications. Each item in the list should display a thumbnail image of the identified species and its name.
*   **Navigation Bar:**
    *   **Home:** (Selected)
    *   **History:**
    *   **Profile:**
