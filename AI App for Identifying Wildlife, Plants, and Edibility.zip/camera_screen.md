_This is a text-based mockup of the camera screen._

# Camera Screen

*   **Viewfinder:** The majority of the screen will be occupied by the camera's viewfinder.
*   **Capture Button:** A large, circular button at the bottom center of the screen to capture an image.
*   **Gallery Button:** A small button, likely in the bottom left corner, to allow users to select an image from their device's gallery.
*   **Flash Toggle:** An icon to toggle the camera's flash on or off.
*   **Switch Camera:** An icon to switch between the front and rear-facing cameras.
*   **Identification Tips:** A small, dismissible overlay with tips for taking good identification photos (e.g., "Get as close as you can," "Focus on a single subject").
